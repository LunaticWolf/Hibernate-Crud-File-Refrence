package com.nu.jsp.javaclasses;

public class A
{
  public static String make(String data)
  {
	  return data.toUpperCase();
	  
  }

}