package com.nu.servlets.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HelloWorldServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

 
    public HelloWorldServlets() 
    {
        super();
    }  

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		//Set content type as response to browser
		
		response.setContentType("text/html");
		
		//Set Printwriter
		
		PrintWriter out = response.getWriter();
		
		//generate html content
		
		out.println("<html> <head> <title> HelloWorldServlet</title> </head> <body> ");

		out.println("<h2> Hello World </h2> <br> <hr>");
		
		out.println("<h3> The Time is: </h3> " + new java.util.Date());
		
		out.println("</br> </body> </html>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

}
