<html> 
<head> <title> Nav-Bar </title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>


</head>


<body class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#"> N-Data </a>
		</div>

		<div> 
			<ul class="nav navbar-nav"> 
				<li> <a href="#"> New </a></li>
				<li> <a href="#"> Update</a></li>
				<li class="dropdown"> 
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown"> View
					  	 <span class="caret"></span>
					  </a>
				
                 	<ul class="dropdown-menu">
                    		<li> <a href="#"> a </a> </li>
                    		<li> <a href="#"> b </a> </li>
                    		<li> <a href="#"> c </a>
                  	</ul> 

				</li>
				<li class="active"> <a href="#"> Delete </a></li>
				<li> <a href="#"> Logout</a></li>
			</ul>
		</div>
	</div>
</body>



</html>



