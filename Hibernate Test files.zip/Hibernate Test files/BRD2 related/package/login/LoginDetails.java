package com.nucleus.brd2.hibernate.login;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="login")
public class LoginDetails 
{

	private String userCode;
	private String userId;
	private String passWord;
    private String role;
    
    
    
    //Getters
    
	public String getUserCode() {
		return userCode;
	}
	public String getUserId() {
		return userId;
	}
	public String getPassWord() {
		return passWord;
	}
	public String getRole() {
		return role;
	}
	
	

	//setters
		
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
	public LoginDetails(String userCode, String userId, String passWord,
			String role) {
		super();
		this.userCode = userCode;
		this.userId = userId;
		this.passWord = passWord;
		this.role = role;
	}
	
	
	
    
	
    
}
