package com.nucleus.brd2.hibernate.customer.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Yin")
public class Customer 
{
	public Customer(){}
	
	//Customer Field;
		
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="customer_id")
	private int customerId;
	
	@Column(name="customer_code")
	private String customerCode;
	
	@Column(name="customer_name")
	private String customerName;
	
	@Column(name="customer_address1")
	private String customerAddress1;
	
	@Column(name="customer_address2")
	private String customerAddress2;
	
	@Column(name="customer_pincode")
	private int customerPinCode;
	
	@Column(name="customer_email")
	private String emailAddress;
	
	@Column(name="customer_contactnumber")
	private String contactNumber;
	
	@Column(name="customer_primarycontactperson")
	private String primaryConatctPerson;
	
	@Column(name="customer_recordstatus")
	private String recordStatus;
	
	@Column(name="customer_flag")
	private String activeInactiveFlag;

	@Column(name="create_date")
	private String createDate;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="modified_date")
	private String modifiedDate;
	
	@Column(name="modified_by")
	private String modifiedBy;
	

	@Column(name="authorized_date")
	private String authorizedDate;
	
	@Column(name="authorized_by")
	private String authorizedBy;
	
	
	
	
	
	
	//Getters
	public int getCustomerId() {
		return customerId;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getCustomerAddress1() {
		return customerAddress1;
	}

	public String getCustomerAddress2() {
		return customerAddress2;
	}

	public int getCustomerPinCode() {
		return customerPinCode;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public String getPrimaryConatctPerson() {
		return primaryConatctPerson;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public String getActiveInactiveFlag() {
		return activeInactiveFlag;
	}

	public String getCreateDate() {
		return createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public String getAuthorizedDate() {
		return authorizedDate;
	}

	public String getAuthorizedBy() {
		return authorizedBy;
	}

	
	
	//Setters
		
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}

	public void setCustomerAddress2(String customerAddress2) {
		this.customerAddress2 = customerAddress2;
	}

	public void setCustomerPinCode(int customerPinCode) {
		this.customerPinCode = customerPinCode;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setPrimaryConatctPerson(String primaryConatctPerson) {
		this.primaryConatctPerson = primaryConatctPerson;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public void setActiveInactiveFlag(String activeInactiveFlag) {
		this.activeInactiveFlag = activeInactiveFlag;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public void setAuthorizedDate(String authorizedDate) {
		this.authorizedDate = authorizedDate;
	}

	public void setAuthorizedBy(String authorizedBy) {
		this.authorizedBy = authorizedBy;
	}

	
	
	
	//Parametric Constructor
	public Customer(int customerId, String customerCode, String customerName,
			String customerAddress1, String customerAddress2,
			int customerPinCode, String emailAddress, String contactNumber,
			String primaryConatctPerson, String recordStatus,
			String activeInactiveFlag, String createDate, String createdBy,
			String modifiedDate, String modifiedBy, String authorizedDate,
			String authorizedBy) {
		super();
		this.customerId = customerId;
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddress2 = customerAddress2;
		this.customerPinCode = customerPinCode;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.primaryConatctPerson = primaryConatctPerson;
		this.recordStatus = recordStatus;
		this.activeInactiveFlag = activeInactiveFlag;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
		this.authorizedDate = authorizedDate;
		this.authorizedBy = authorizedBy;
	}
	
	
	
	//ToString

	@Override
	public String toString() {
		return "Customer [customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress1=" + customerAddress1
				+ ", customerAddress2=" + customerAddress2
				+ ", customerPinCode=" + customerPinCode + ", emailAddress="
				+ emailAddress + ", contactNumber=" + contactNumber
				+ ", primaryConatctPerson=" + primaryConatctPerson
				+ ", recordStatus=" + recordStatus + ", activeInactiveFlag="
				+ activeInactiveFlag + ", createDate=" + createDate
				+ ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + ", authorizedDate="
				+ authorizedDate + ", authorizedBy=" + authorizedBy + "]";
	}

	
	
	
	
	
	
	
	
	
	}