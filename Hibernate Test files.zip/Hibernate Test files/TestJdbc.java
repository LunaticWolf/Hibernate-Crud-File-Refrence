package com.nu.hibernate.test.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestJdbc 
{

	
	public static void main(String args[]) throws ClassNotFoundException
	{
		String driverclass = "oracle.jdbc.driver.OracleDriver";
		String url ="jdbc:oracle:thin:@10.1.50.198:1521:orcl";
		String user = "sh";
		String password = "sh";
		Connection conn=null;
		
		try
		{
			System.out.println("Connecting to...\n" + url);
			Class.forName(driverclass);
			conn = DriverManager.getConnection(url,user,password);
			
			System.out.println("Done..");
		}
		
		catch (SQLException e) 
		{
			System.out.println(" Driver Class not found");
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) 
		{	
            System.out.println("Error - \n Driver Class Not Loaded...\nClassNotFound Exception Encountered while setting up JDBC connection..");
			e.printStackTrace();
		}

	
	}
}
